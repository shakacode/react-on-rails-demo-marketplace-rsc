import type { ReactNode } from 'react';
export type RSCProviderCacheIdentity = object;
export declare const getReusablePrefetchedServerComponent: (key: string) => Promise<ReactNode> | undefined;
export declare const consumePrefetchedServerComponent: (key: string, providerCacheIdentity: RSCProviderCacheIdentity) => Promise<ReactNode> | undefined;
export declare const setPrefetchedServerComponent: (key: string, promise: Promise<ReactNode>) => void;
export declare const deletePrefetchedServerComponent: (key: string, promise?: Promise<ReactNode>) => void;
/** @internal Test-only reset for module-level prefetch state. */
export declare const resetRSCPrefetchStoreForTesting: () => void;
//# sourceMappingURL=RSCPrefetchStore.d.ts.map