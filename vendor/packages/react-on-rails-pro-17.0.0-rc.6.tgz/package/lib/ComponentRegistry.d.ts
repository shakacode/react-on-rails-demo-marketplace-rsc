import { type RegisteredComponent, type RegisteredComponentValue } from 'react-on-rails/types';
type RegisteredComponentEntry = RegisteredComponent<RegisteredComponentValue>;
/**
 * @param components { component1: component1, component2: component2, etc. }
 * @public
 */
export declare function register(components: Record<string, RegisteredComponentValue>): void;
/**
 * @param name
 * @returns { name, component, isRenderFunction, isRenderer }
 */
export declare const get: (name: string) => RegisteredComponentEntry;
export declare const getOrWaitForComponent: (name: string) => Promise<RegisteredComponentEntry>;
/**
 * Get a Map containing all registered components. Useful for debugging.
 * @returns Map where key is the component name and values are the
 * { name, component, renderFunction, isRenderer}
 * @public
 */
export declare const components: () => Map<string, RegisteredComponentEntry>;
/** @internal Exported only for tests */
export declare function clear(): void;
export {};
//# sourceMappingURL=ComponentRegistry.d.ts.map