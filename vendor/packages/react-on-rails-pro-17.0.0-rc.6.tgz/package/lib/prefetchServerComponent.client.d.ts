export type PrefetchServerComponentOptions = {
    signal?: AbortSignal;
    skipIfEmbedded?: boolean;
};
export declare const prefetchServerComponent: (componentName: string, componentProps: unknown, { signal, skipIfEmbedded }?: PrefetchServerComponentOptions) => Promise<void>;
//# sourceMappingURL=prefetchServerComponent.client.d.ts.map