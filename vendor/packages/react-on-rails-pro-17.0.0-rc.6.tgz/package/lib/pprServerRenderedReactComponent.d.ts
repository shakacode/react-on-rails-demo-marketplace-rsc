import { Readable } from 'stream';
import type { PostponedState } from 'react-dom/static';
import { RenderParams } from 'react-on-rails/types';
export interface PPRResumeRenderParams extends RenderParams {
    postponedState: PostponedState;
}
export declare const pprPrerenderServerRenderedReactComponent: (options: RenderParams) => Readable;
export declare const pprResumeServerRenderedReactComponent: (options: PPRResumeRenderParams) => Readable;
//# sourceMappingURL=pprServerRenderedReactComponent.d.ts.map