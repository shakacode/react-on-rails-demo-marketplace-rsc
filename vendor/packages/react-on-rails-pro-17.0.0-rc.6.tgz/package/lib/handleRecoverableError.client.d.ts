import type { ReactHydrateOptions } from 'react-on-rails/reactApis';
/**
 * Builds an `onRecoverableError` root option that chains Pro's internal recoverable-error
 * reporting with a user-registered `rootErrorHandlers.onRecoverableError` callback (already
 * wrapped with React on Rails context by `buildRootErrorCallbackOptions`). Both run for every
 * real recoverable error: internal reporting first (preserving the pre-existing Pro behavior),
 * then the user callback.
 *
 * The RSCRoute `ssr: false` bailout signal is Pro control flow — a deliberate marker that SSR was
 * skipped for the route, not an application error — so it is filtered before BOTH handlers to
 * keep it out of user error reporting (e.g. Sentry) just as it is kept out of Pro's own reporting.
 *
 * With no user handler, Pro still installs this wrapper so RSC hydrate roots preserve React's
 * default recoverable-error reporting while applying the bailout filter above. That is equivalent
 * to React's native default reporting but keeps Pro's filtering/chaining path uniform.
 *
 * User caution: this wrapper calls `defaultReportRecoverableError` before `next`, so a user
 * `onRecoverableError` callback on Pro RSC hydrate roots should not call `reportError(error)` again.
 * Core/non-RSC roots follow standard React semantics: a registered callback replaces React's default
 * reporting and must re-report if the app needs `window.onerror`/`reportError` coverage.
 */
export declare const chainRecoverableErrorHandlers: (next?: ReactHydrateOptions["onRecoverableError"]) => NonNullable<ReactHydrateOptions["onRecoverableError"]>;
declare const handleRecoverableError: (error: unknown, errorInfo: unknown) => void;
export default handleRecoverableError;
//# sourceMappingURL=handleRecoverableError.client.d.ts.map