export declare const RSC_ROUTE_SSR_FALSE_BAILOUT_DIGEST = "REACT_ON_RAILS_RSC_ROUTE_SSR_FALSE_BAILOUT";
/**
 * Intentional server-only bailout used by `RSCRoute ssr={false}`.
 *
 * React streaming SSR catches errors under Suspense boundaries and emits the nearest fallback.
 * The stream renderer uses this classified error to avoid reporting that intentional fallback
 * path as a real server-rendering failure.
 */
export declare class RSCRouteSSRFalseBailoutError extends Error {
    readonly digest = "REACT_ON_RAILS_RSC_ROUTE_SSR_FALSE_BAILOUT";
    constructor(componentName: string);
}
export declare function isRSCRouteSSRFalseBailoutError(error: unknown): error is RSCRouteSSRFalseBailoutError;
//# sourceMappingURL=RSCRouteSSRFalseBailoutError.d.ts.map