export {};
//# sourceMappingURL=registerDefaultRSCProvider.client.d.ts.map