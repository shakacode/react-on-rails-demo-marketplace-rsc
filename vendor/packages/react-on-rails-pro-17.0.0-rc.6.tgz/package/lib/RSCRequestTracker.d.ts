import { RSCPayloadStreamInfo, RSCPayloadCallback, RailsContextWithServerComponentMetadata, GenerateRSCPayloadFunction } from 'react-on-rails/types';
export declare const hasExpectedRSCStreamCleanup: (stream: NodeJS.ReadableStream) => boolean;
export declare const shouldReportRSCStreamTruncation: (stream: NodeJS.ReadableStream) => boolean;
/**
 * A captured RSC bundle diagnostic for a single component, recorded during stream parse.
 *
 * Kept render-scoped on the tracker so it survives past the `getReactServerComponentOnServer`
 * call that captured it. This is what lets the deferred-render path (where React surfaces the
 * failure through `renderToPipeableStream`'s `onError` rather than rejecting the stream parse)
 * recover the original diagnostic — see #3475.
 */
export interface CapturedRSCDiagnostic {
    componentName: string;
    diagnosticError: Error;
}
/**
 * RSC Request Tracker — manages RSC payload generation and stream tracking per request.
 *
 * This class provides a local alternative to the global RSC payload management,
 * allowing each request to have its own isolated tracker without sharing state.
 * It includes both tracking functionality for the server renderer and fetching
 * functionality for components.
 */
declare class RSCRequestTracker {
    private streams;
    private sourceStreams;
    private cleared;
    private callbacks;
    private capturedRSCDiagnostics;
    private railsContext;
    private generateRSCPayload?;
    constructor(railsContext: RailsContextWithServerComponentMetadata, generateRSCPayload?: GenerateRSCPayloadFunction);
    /**
     * Clears all streams and callbacks for this request.
     * Should be called when the request is complete to ensure proper cleanup,
     * though garbage collection will handle cleanup automatically when the tracker goes out of scope.
     *
     * This method is safe to call multiple times and will handle any errors during cleanup gracefully.
     */
    clear(): void;
    /**
     * Records an RSC bundle diagnostic captured while parsing a component's payload stream.
     *
     * Called from `getReactServerComponentOnServer` when `transformRSCStream` surfaces a
     * `renderingError` via `onDiagnosticError`. Storing it here (render-scoped) lets the surfacing
     * site recover it even when the failure propagates through React's deferred render phase rather
     * than rejecting the stream parse synchronously (#3475).
     *
     * @param componentName - Name of the server component the diagnostic belongs to
     * @param diagnosticError - The diagnostic built by `buildRSCStreamDiagnosticError`
     */
    recordRSCDiagnostic(componentName: string, diagnosticError: Error): void;
    /**
     * Returns all RSC bundle diagnostics captured this render **and clears them**, so a single
     * captured diagnostic is merged into at most one surfaced error.
     *
     * This is the misattribution guard for the deferred-render enrichment (#3475). React's `onError`
     * carries no component key, so the enrichment site cannot prove a given error came from the
     * captured RSC component. The enrichment site consumes first so a matched diagnostic is attached at
     * most once, then restores any non-matching diagnostics for later errors in the same render. This
     * prevents a different Suspense boundary, serialization error, or addPostSSRHook throw from stealing
     * a lone RSC diagnostic before the actual RSC failure surfaces.
     *
     * @returns The captured diagnostics (empty if none were captured or they were already consumed)
     */
    consumeCapturedRSCDiagnostics(): CapturedRSCDiagnostic[];
    /**
     * Restores consumed diagnostics that were not matched to the current surfaced error.
     *
     * These entries already came from `capturedRSCDiagnostics`, so they have passed
     * `recordRSCDiagnostic`'s dedup filter. Push them back directly to preserve the exact consumed
     * set without re-running deduplication during restore.
     *
     * @internal Only restore arrays previously returned by `consumeCapturedRSCDiagnostics`.
     *
     * @param captured - Previously consumed diagnostics to make available for a later surfaced error
     */
    restoreCapturedRSCDiagnostics(captured: CapturedRSCDiagnostic[]): void;
    /**
     * Registers a callback to be executed when RSC payloads are generated.
     *
     * This function:
     * 1. Stores the callback function for this tracker
     * 2. Immediately executes the callback for any existing streams
     *
     * This synchronous execution is critical for preventing hydration race conditions.
     * It ensures payload array initialization happens before component HTML appears
     * in the response stream.
     *
     * @param callback - Function to call when an RSC payload is generated
     */
    onRSCPayloadGenerated(callback: RSCPayloadCallback): void;
    /**
     * Generates and tracks RSC payloads for server components.
     *
     * getRSCPayloadStream:
     * 1. Calls the provided generateRSCPayload function
     * 2. Tracks streams in this tracker for later access
     * 3. Notifies callbacks immediately to enable early payload embedding
     *
     * The immediate callback notification is critical for preventing hydration race conditions,
     * as it ensures the payload array is initialized in the HTML stream before component rendering.
     *
     * @param componentName - Name of the server component
     * @param props - Props for the server component
     * @returns A stream of the RSC payload
     * @throws Error if generateRSCPayload is not available or fails
     */
    getRSCPayloadStream(componentName: string, props: unknown): Promise<NodeJS.ReadableStream>;
    /**
     * Returns all RSC payload streams tracked by this request tracker.
     * Used by the server renderer to access all fetched RSCs for this request.
     *
     * @returns Array of RSC payload stream information
     */
    getRSCPayloadStreams(): RSCPayloadStreamInfo[];
}
export default RSCRequestTracker;
//# sourceMappingURL=RSCRequestTracker.d.ts.map