/** Shared implementation used by both the capability object and proClientStartup. */
export declare function reactOnRailsPageLoaded(): Promise<void>;
/**
 * Pro lifecycle capability.
 * Overrides core lifecycle with Pro implementations that support hydration
 * and on-demand rendering.
 */
export declare function createProLifecycleCapability(): {
    reactOnRailsPageLoaded: typeof reactOnRailsPageLoaded;
    reactOnRailsComponentLoaded(domId: string): Promise<void>;
};
//# sourceMappingURL=proLifecycle.d.ts.map