import { Readable } from 'stream';
import { RSCRenderParams } from 'react-on-rails/types';
/**
 * Pro RSC capability.
 * Provides React Server Components rendering support.
 */
export declare function createProRSCCapability(): {
    isRSCBundle: true;
    serverRenderRSCReactComponent(options: RSCRenderParams): Readable;
    addAsyncPropsCapabilityToComponentProps<AsyncPropsType extends Record<string, unknown>, PropsType extends Record<string, unknown>>(props: PropsType, sharedExecutionContext: Map<string, unknown>): {
        props: PropsType & {
            getReactOnRailsAsyncProp: <PropName extends keyof AsyncPropsType>(propName: PropName) => Promise<AsyncPropsType[PropName]>;
        };
    };
    getOrCreateAsyncPropsManager(sharedExecutionContext: Map<string, unknown>): import("../AsyncPropsManager.ts").default;
};
//# sourceMappingURL=proRSC.d.ts.map