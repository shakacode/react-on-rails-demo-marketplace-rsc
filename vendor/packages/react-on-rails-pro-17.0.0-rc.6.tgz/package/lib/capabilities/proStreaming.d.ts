import type { Readable } from 'stream';
import type { RenderParams } from 'react-on-rails/types';
import { type PPRResumeRenderParams } from '../pprServerRenderedReactComponent.ts';
/**
 * Pro streaming capability.
 * Provides server-side streaming rendering via streamServerRenderedReactComponent,
 * and experimental PPR (Partial Prerendering) via prerender/resume functions.
 */
export declare function createProStreamingCapability(): {
    streamServerRenderedReactComponent(options: RenderParams): Readable;
    pprPrerenderServerRenderedReactComponent(options: RenderParams): Readable;
    pprResumeServerRenderedReactComponent(options: PPRResumeRenderParams): Readable;
};
//# sourceMappingURL=proStreaming.d.ts.map