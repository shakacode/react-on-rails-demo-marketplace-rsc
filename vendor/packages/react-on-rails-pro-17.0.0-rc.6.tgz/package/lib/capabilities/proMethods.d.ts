import type { RegisteredComponent, RegisteredComponentValue, Store, StoreGenerator } from 'react-on-rails/types';
/**
 * Pro methods capability.
 * Provides Pro-only features: async component/store access and store hydration.
 */
export declare function createProMethodCapability(): {
    getOrWaitForComponent(name: string): Promise<RegisteredComponent<RegisteredComponentValue>>;
    getOrWaitForStore(name: string): Promise<Store>;
    getOrWaitForStoreGenerator(name: string): Promise<StoreGenerator>;
    reactOnRailsStoreLoaded(storeName: string): Promise<void>;
};
//# sourceMappingURL=proMethods.d.ts.map