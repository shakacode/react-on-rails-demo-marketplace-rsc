import { Writable } from 'stream';
import { PipeableOrReadableStream } from 'react-on-rails/types';
/**
 * Pipes source to destination with proper 'close' event handling.
 *
 * Node.js `pipe()` does NOT end the destination when the source is destroyed —
 * it silently unpipes, leaving the destination open forever. This function fills
 * that gap by listening for the 'close' event (which fires after both normal
 * 'end' and `destroy()`) and ending the destination if the source didn't end
 * normally.
 *
 * An optional `onError` callback provides observability for source stream errors
 * without forwarding them to the destination (which would break the pipe).
 *
 * NOTE: `PipeableOrReadableStream` can be either a React `PipeableStream`
 * (which only has `.pipe()` and `.abort()`, no `.on()`) or a Node.js
 * `ReadableStream`. The 'close' and 'error' listeners are only attached when
 * the source supports `.on()`.
 *
 * @param source - The source stream to pipe from
 * @param destination - The destination stream to pipe into
 * @param onError - Optional callback for source stream errors (for reporting, not forwarding)
 * @returns The destination stream (for chaining)
 */
export default function safePipe<T extends Writable>(source: PipeableOrReadableStream, destination: T, onError?: (err: Error) => void): T;
//# sourceMappingURL=safePipe.d.ts.map