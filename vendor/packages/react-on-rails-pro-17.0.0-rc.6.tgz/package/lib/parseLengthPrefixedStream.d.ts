export default class LengthPrefixedStreamParser {
    private buf;
    private state;
    private contentLen;
    private metadata;
    feed(chunk: Uint8Array, onChunk: (content: Uint8Array, metadata: Record<string, unknown>) => void): void;
    flush(): void;
}
//# sourceMappingURL=parseLengthPrefixedStream.d.ts.map