declare const ASYNC_PROPS_MANAGER_KEY = "asyncPropsManager";
declare const PULL_ENABLED_KEY = "pullEnabled";
declare const PUSH_PROPS_KEY = "pushProps";
declare const PROP_REQUEST_EMITTER_KEY = "propRequestEmitter";
declare const MAX_PULL_PROP_NAME_LENGTH = 256;
declare class AsyncPropsManager {
    private static readonly MAX_BUFFERED_REQUESTS;
    private isClosed;
    private propNameToPromiseController;
    private sharedExecutionContext;
    private bufferedPropRequests;
    private overCapBufferedPropRequestCount;
    constructor(sharedExecutionContext?: Map<string, unknown>);
    /**
     * Gets the promise for an async prop. Returns the SAME promise on repeated calls.
     *
     * IMPORTANT: This is not an async function intentionally.
     * Returning the same Promise object on every call is required for React's
     * concurrent rendering - new promises would cause re-renders.
     *
     * In pull mode (pullEnabled=true), emits a propRequest for non-push props
     * that haven't been received yet, asking Rails to resolve them on demand.
     */
    getProp(propName: string): Promise<unknown>;
    setProp(propName: string, propValue: unknown): void;
    rejectProp(propName: string, reason: string): void;
    endStream(): void;
    /**
     * Called by the node renderer after installing propRequestEmitter on sharedExecutionContext.
     *
     * The order is intentional: buffered requests were already marked `pullRequested`
     * while no emitter was installed, then never-flagged controllers are caught up.
     * Keeping this as one method prevents callers from reversing the order and
     * duplicating buffered requests.
     */
    catchUpPropRequests(): void;
    /**
     * @deprecated Kept for older node renderers during mixed-version deploys.
     */
    flushPendingPullRequests(): void;
    /**
     * @deprecated Kept for older node renderers during mixed-version deploys.
     */
    emitPendingPullRequests(): void;
    private isPullEnabled;
    private isPushProp;
    private getPropRequestEmitter;
    private emitPropRequest;
    private static rejectOversizedPullPropRequest;
    private static rejectOversizedPullPropRequestInPlace;
    private getOrCreatePromiseController;
    private static getNoPropFoundError;
    private static getOversizedPropNameError;
}
/**
 * Gets or creates an AsyncPropsManager from the shared execution context.
 *
 * This function implements lazy initialization to handle race conditions between
 * the initial render request and update chunks. Whichever executes first will
 * create the manager, and subsequent calls will reuse the same instance.
 *
 * @param sharedExecutionContext - Map scoped to the current HTTP request
 * @returns The AsyncPropsManager instance (existing or newly created)
 */
export declare function getOrCreateAsyncPropsManager(sharedExecutionContext: Map<string, unknown>): AsyncPropsManager;
export { PULL_ENABLED_KEY, PUSH_PROPS_KEY, PROP_REQUEST_EMITTER_KEY, ASYNC_PROPS_MANAGER_KEY, MAX_PULL_PROP_NAME_LENGTH, };
export default AsyncPropsManager;
//# sourceMappingURL=AsyncPropsManager.d.ts.map