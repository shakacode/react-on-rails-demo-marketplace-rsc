export declare function proClientStartup(): void;
//# sourceMappingURL=proClientStartup.d.ts.map