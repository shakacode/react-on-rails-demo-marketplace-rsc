type RSCStreamDiagnosticContext = {
    componentName?: string;
    source?: string;
};
export type RSCStreamDiagnosticsOptions = RSCStreamDiagnosticContext & {
    onDiagnosticError?: (error: Error) => void;
};
export declare const RSC_STREAM_DIAGNOSTIC_ERROR_NAME = "ReactOnRailsRSCStreamError";
export declare const MERGED_DIAGNOSTIC_FLAG = "__rorRSCDiagMerged";
export declare const REACT_STREAM_ERROR_SEPARATOR = "\nReact stream error:";
type RSCStreamDiagnosticError = Error & {
    [MERGED_DIAGNOSTIC_FLAG]?: true;
    cause?: unknown;
};
export declare const rscStreamDiagnosticMatchesError: (streamError: Error) => boolean;
export declare const extractModulePathFromStack: (stack?: string) => string | undefined;
export declare const buildRSCStreamDiagnosticError: (metadata: Record<string, unknown>, context?: RSCStreamDiagnosticContext) => Error | undefined;
/**
 * Builds a single combined diagnostic from multiple captured RSC bundle diagnostics.
 *
 * Used for the deferred-render path when more than one RSC component diagnostic was captured this
 * render (#3475). React's `onError` carries no component key, so the failing component is ambiguous;
 * rather than pinpoint one (which could be wrong), this lists every captured component diagnostic as
 * a candidate. The returned error mirrors the shape of `buildRSCStreamDiagnosticError` so the
 * existing `mergeRSCStreamDiagnosticError` flow can consume it.
 *
 * Handles 0/1/2+ defensively: returns `undefined` for an empty list and the single entry unchanged
 * for one, so callers don't need to pre-check length. The combined error is deliberately a *fresh*
 * diagnostic — it does NOT carry `MERGED_DIAGNOSTIC_FLAG` — so it is meant to be passed as the
 * `diagnosticError` (second) argument to `mergeRSCStreamDiagnosticError`, never as the stream error
 * (first) argument.
 *
 * Precondition: every entry must be a raw diagnostic from `buildRSCStreamDiagnosticError`, never an
 * already-merged error. Passing a merged error would embed its full prior-merged text into a
 * candidate block. Dev/test throws on that precondition failure; production logs and drops the
 * invalid merged entries before building a combined candidate message.
 *
 * @param diagnosticErrors - Diagnostics built by `buildRSCStreamDiagnosticError` (0, 1, or more)
 */
export declare const combineRSCStreamDiagnosticErrors: (diagnosticErrors: Error[]) => Error | undefined;
/**
 * Merges a generic React stream error with the original RSC bundle diagnostic.
 *
 * Idempotent on `error`: if `error` is already a merged result (carries `MERGED_DIAGNOSTIC_FLAG`)
 * it is returned untouched, so re-entering this in a chain of catch handlers won't double-wrap.
 *
 * Precondition: `diagnosticError` must be a fresh (non-merged) diagnostic — in practice it always
 * comes from `buildRSCStreamDiagnosticError`, which never sets the flag. The idempotency guard
 * intentionally only inspects `error`; passing an already-merged error as `diagnosticError` would
 * duplicate context.
 */
export declare const mergeRSCStreamDiagnosticError: (error: unknown, diagnosticError?: Error) => RSCStreamDiagnosticError;
export declare const extractMergedRSCStreamDiagnosticMessage: (error: Error) => string;
export {};
//# sourceMappingURL=rscDiagnostics.d.ts.map