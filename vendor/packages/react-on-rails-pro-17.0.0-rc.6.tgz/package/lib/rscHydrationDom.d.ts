import type { RailsContext } from 'react-on-rails/types';
export declare function shouldPrepareRSCHydrationRoot(railsContext: RailsContext | undefined): boolean;
export declare function hasLeadingSuspenseBoundary(domNode: Element | null | undefined): boolean;
export default function prepareRSCHydrationRoot(domNode: Element): void;
//# sourceMappingURL=rscHydrationDom.d.ts.map