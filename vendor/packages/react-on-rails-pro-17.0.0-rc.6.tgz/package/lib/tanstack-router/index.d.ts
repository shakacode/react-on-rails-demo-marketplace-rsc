/**
 * TanStack Router integration for React on Rails Pro.
 *
 * This module provides utilities to use TanStack Router with React on Rails Pro's
 * async Node Renderer SSR pipeline. It requires `rendering_returns_promises = true`
 * in your React on Rails Pro configuration.
 *
 * @example
 * ```typescript
 * import { createTanStackRouterRenderFunction } from 'react-on-rails-pro/tanstack-router';
 * import { createRouter, RouterProvider, createMemoryHistory, createBrowserHistory } from '@tanstack/react-router';
 * import { routeTree } from './routeTree.gen';
 * import ReactOnRails from 'react-on-rails-pro';
 *
 * const TanStackApp = createTanStackRouterRenderFunction(
 *   {
 *     createRouter: () => createRouter({ routeTree }),
 *   },
 *   { RouterProvider, createMemoryHistory, createBrowserHistory },
 * );
 *
 * ReactOnRails.register({ TanStackApp });
 * ```
 *
 * @remarks
 * TanStack Router SSR requires React on Rails Pro with the Node Renderer.
 * This intentionally uses the async renderer path rather than ExecJS-backed sync SSR.
 * If you encounter issues after upgrading @tanstack/react-router, update react-on-rails-pro
 * or file an issue at https://github.com/shakacode/react_on_rails/issues
 *
 * @packageDocumentation
 */
import type { RenderFunction } from 'react-on-rails/types';
import type { TanStackHistory, TanStackRouter, TanStackRouterOptions } from './types.ts';
export type { TanStackRouterOptions, DehydratedRouterState } from './types.ts';
export { serverRenderTanStackAppAsync } from './serverRender.ts';
interface TanStackRouterDeps {
    /**
     * The RouterProvider component from @tanstack/react-router.
     * We require this as a parameter to avoid a direct dependency on @tanstack/react-router.
     */
    RouterProvider: React.ComponentType<{
        router: TanStackRouter;
    }>;
    /**
     * @deprecated No longer used for hydration. RouterProvider is always used
     * directly to match the server-rendered tree. RouterClient caused hydration
     * mismatches because it wraps RouterProvider in <Await> which suspends.
     * Kept for backward compatibility only.
     */
    RouterClient?: React.ComponentType<{
        router: TanStackRouter;
    }>;
    /**
     * The createMemoryHistory function from @tanstack/react-router.
     * Used for server-side rendering.
     */
    createMemoryHistory: (opts: {
        initialEntries: string[];
    }) => TanStackHistory;
    /**
     * The createBrowserHistory function from @tanstack/react-router.
     * Used for client-side hydration.
     */
    createBrowserHistory: () => TanStackHistory;
}
/**
 * Creates a React on Rails render function for a TanStack Router application.
 *
 * This function returns a render function that can be registered with `ReactOnRails.register()`.
 * On the server, it uses the async `router.load()` API via React on Rails Pro's Node Renderer.
 * On the client, it hydrates using the dehydrated router state from the server.
 *
 * Requires `rendering_returns_promises = true` in your React on Rails Pro configuration.
 *
 * @param options - Configuration for the TanStack Router app
 * @param deps - TanStack Router dependencies (RouterProvider, createMemoryHistory, createBrowserHistory)
 * @returns A render function compatible with ReactOnRails.register()
 */
export declare function createTanStackRouterRenderFunction(options: TanStackRouterOptions, deps: TanStackRouterDeps): RenderFunction;
//# sourceMappingURL=index.d.ts.map