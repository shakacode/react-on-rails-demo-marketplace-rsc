import * as React from 'react';
import type { TanStackHistory, TanStackRouter, TanStackRouterOptions } from './types.ts';
import type { RailsContext } from 'react-on-rails/types';
export declare function clientHydrateTanStackApp(options: TanStackRouterOptions, props: Record<string, unknown>, railsContext: RailsContext & {
    serverSide: false;
}, RouterProvider: React.ComponentType<{
    router: TanStackRouter;
}>, createBrowserHistory: () => TanStackHistory): React.ReactElement;
//# sourceMappingURL=clientHydrate.d.ts.map