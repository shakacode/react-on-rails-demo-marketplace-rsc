export declare function normalizeSearch(search: string | null | undefined): string;
//# sourceMappingURL=utils.d.ts.map