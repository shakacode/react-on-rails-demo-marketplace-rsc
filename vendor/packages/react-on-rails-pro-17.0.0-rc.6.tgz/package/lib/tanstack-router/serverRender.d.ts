import { type ReactElement } from 'react';
import type { DehydratedRouterState, TanStackHistory, TanStackRouter, TanStackRouterOptions } from './types.ts';
import type { RailsContext } from 'react-on-rails/types';
export interface TanStackServerRenderResult {
    appElement: ReactElement;
    dehydratedState: DehydratedRouterState;
}
/**
 * Async server-side render for use with React on Rails Pro Node Renderer.
 * Uses the public router.load() API — no private API workarounds needed.
 *
 * Requires: rendering_returns_promises = true in React on Rails Pro config.
 */
export declare function serverRenderTanStackAppAsync(options: TanStackRouterOptions, props: Record<string, unknown>, railsContext: RailsContext & {
    serverSide: true;
}, RouterProvider: React.ComponentType<{
    router: TanStackRouter;
}>, createMemoryHistory: (opts: {
    initialEntries: string[];
}) => TanStackHistory): Promise<TanStackServerRenderResult>;
//# sourceMappingURL=serverRender.d.ts.map