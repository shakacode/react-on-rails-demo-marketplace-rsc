declare const ReactOnRails: import("react-on-rails/types").ReactOnRailsInternal;
export * from 'react-on-rails/types';
export { unstable_cache, registerCacheHandler } from './cache/index.ts';
export type { CacheHandler, CacheEntry, UnstableCacheOptions } from './cache/index.ts';
export default ReactOnRails;
//# sourceMappingURL=ReactOnRailsRSC.d.ts.map