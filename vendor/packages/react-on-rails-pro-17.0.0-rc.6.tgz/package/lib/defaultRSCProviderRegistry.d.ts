import type { ReactElement } from 'react';
import type { RailsContext } from 'react-on-rails/types';
type DefaultRSCProviderFactory = ({ reactElement, railsContext, domNodeId, }: {
    reactElement: ReactElement;
    railsContext: RailsContext;
    domNodeId: string;
}) => ReactElement;
export declare const setDefaultRSCProviderFactory: (factory: DefaultRSCProviderFactory) => void;
/** @internal Exported only for tests */
export declare const clearDefaultRSCProviderFactory: () => void;
export declare const maybeWrapWithDefaultRSCProviderWithStatus: (reactElement: ReactElement, railsContext: RailsContext, domNodeId: string) => {
    reactElement: ReactElement;
    wrappedByDefaultRSCProvider: boolean;
};
export {};
//# sourceMappingURL=defaultRSCProviderRegistry.d.ts.map