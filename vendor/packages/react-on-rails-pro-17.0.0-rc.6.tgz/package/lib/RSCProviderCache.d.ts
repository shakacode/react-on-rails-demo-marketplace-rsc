/**
 * Maximum number of distinct RSC payload keys the provider-scoped promise cache
 * retains. High-cardinality `componentProps` (e.g. per-row or per-search-query
 * routes) would otherwise grow the cache unbounded for the provider's whole
 * lifetime. When the cap is exceeded the least-recently-used key is evicted
 * along with all of its companion bookkeeping (last-successful promise and
 * refetch version). The common case — a small, stable set of routes — never
 * hits the cap, so cache hits, refetch, and recoverOnError restore are
 * unaffected.
 *
 * The cap is soft while entries are pinned. Besides in-flight and mounted
 * payloads, a terminal browser rejection stays pinned for its short retention
 * window so LRU pressure cannot erase its retry limit and reopen a request
 * loop. A high-cardinality outage can therefore keep more than 50 failures
 * briefly; each is removed and unpinned when that window ends. This cap is
 * intentionally not configurable through `createRSCProvider` today. See
 * https://github.com/shakacode/react_on_rails/issues/3564.
 *
 * NOTE: the per-key `useSyncExternalStore` subscription/fan-out optimization
 * from #3564 is intentionally deferred pending profiling; only eviction is
 * implemented here.
 *
 * TODO(#3564): Consider exposing this as a `createRSCProvider` option if apps
 * need to tune the cap for unusually high-cardinality RSC routes.
 */
export declare const RSC_PAYLOAD_CACHE_MAX_ENTRIES = 50;
/** How long a terminal browser rejection remains protected from render-driven reloads. */
export declare const RSC_PAYLOAD_FAILURE_RETENTION_MS = 5000;
/**
 * Evicted-success markers need a wider window than the primary payload cache:
 * primary-cache churn can evict many successful keys before a mounted route asks
 * for one of those keys again. Keep the marker bookkeeping bounded, but do not
 * drop markers as soon as the primary cache churns once through its own cap.
 * The 4x window keeps a marker through four full primary-cache rotations before
 * never-revisited keys age out.
 */
export declare const RSC_EVICTED_SUCCESS_MARKER_MAX_ENTRIES: number;
/**
 * A tiny insertion-ordered LRU over a `Map`. `get` and `set` move the key to
 * the most-recently-used position (end of the Map), while `get(key, false)` is
 * a recency-neutral read. Values must not be `undefined`; `undefined` is the
 * cache-miss sentinel. When `set` pushes the size past `maxEntries`, the
 * least-recently-used key (front of the Map) is evicted and passed to `onEvict`
 * so callers can drop companion state keyed by the same payload key.
 *
 * A key can be `pin`-ned to prevent eviction while it is in-flight or mounted.
 * Pins are REF-COUNTED: each `pin` increments and each `unpin` decrements a
 * per-key counter, and the key is only evictable once the count returns to
 * zero. This is required for three reasons:
 *
 * 1. Overlapping same-key `refetch()` calls each take their own pin/unpin pair
 *    — a plain set would let the first call's `unpin` drop the pin while a
 *    second refetch is still in flight.
 * 2. Initial `getComponent()` loads are also pinned until they settle so that
 *    a burst of 50+ other keys cannot evict the key before its successful
 *    payload is recorded in `lastSuccessfulRSCPromisesRef` (which is used to
 *    restore the last-good view in `recoverOnError` refetch paths).
 * 3. Mounted `<RSCRoute>` entries retain their payload keys so provider-wide
 *    refreshes do not make visible routes miss and refetch just because the
 *    provider cache contains more mounted routes than the soft cap.
 * 4. Terminal browser failures retain their rejected promise briefly so cache
 *    pressure cannot give the same failing key a fresh request budget before
 *    React consumes the rejection.
 *
 * Inserting an in-flight promise uses `setPinned`, which pins BEFORE running
 * eviction so the just-inserted key can never be chosen as the eviction victim
 * even when every other key is already pinned (a pure `set` then `pin` would
 * let `evictIfNeeded` drop the new unpinned key first). When every key is
 * pinned the map is allowed to temporarily exceed `maxEntries`; matching
 * releases reconcile it, while terminal failures remove themselves at the end
 * of their retention window.
 *
 * No external LRU dependency exists for this synchronous provider cache (the
 * repo's `InMemoryLRUCacheHandler` is an async `CacheHandler` tied to
 * `CacheEntry`), so this minimal helper mirrors that same Map-based pattern.
 *
 * Exported from this internal source module for unit testing; not part of the
 * package export map.
 */
export declare class BoundedLRU<V> {
    private readonly maxEntries;
    private readonly onEvict;
    private map;
    private pins;
    private evicting;
    constructor(maxEntries: number, onEvict: (key: string) => void);
    get(key: string, promote?: boolean): V | undefined;
    /**
     * Raw write for values that do not need an outstanding protection pin. Use
     * `setPinned` for in-flight payloads and `pin` for mounted payloads so
     * eviction cannot drop entries that are pending or visible on screen.
     */
    set(key: string, value: V): void;
    /**
     * Insert (or refresh) `key` and pin it atomically — the pin is registered
     * BEFORE eviction runs. This is required when inserting an in-flight promise
     * into an already-full cache whose every other key is pinned: a plain `set`
     * would run `evictIfNeeded` with the just-inserted (still-unpinned) key as
     * the ONLY evictable candidate and delete it immediately, leaving an orphan
     * pin and breaking last-successful tracking for that mounted route. Pinning
     * first makes the new key un-evictable, so the map is allowed to temporarily
     * exceed `maxEntries` (reconciled by the matching `unpin`). The pin is still
     * registered only after the key is live in the map, so no orphan pin can
     * outlive an absent map entry.
     */
    setPinned(key: string, value: V): void;
    pin(key: string): boolean;
    deleteWithoutEvict(key: string, preservePins?: boolean): void;
    deletePreservingPins(key: string): void;
    unpin(key: string): void;
    unpinWithoutEvict(key: string): void;
    private releasePin;
    /**
     * Evict least-recently-used unpinned keys until the map is back within
     * `maxEntries`. `preventEvictingKey`, when given, is treated as un-evictable
     * for this reconciliation (in addition to pinned keys) so a key that was JUST
     * unpinned after its in-flight load settled is not evicted by its own
     * `unpin`. If every evictable candidate is pinned or protected, the loop stops
     * and the map is allowed to stay temporarily over cap until the next
     * reconciliation.
     */
    private evictIfNeeded;
    private assertNotEvicting;
}
//# sourceMappingURL=RSCProviderCache.d.ts.map