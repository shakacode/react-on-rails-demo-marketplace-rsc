export type PrefetchServerComponentOptions = {
    signal?: AbortSignal;
    skipIfEmbedded?: boolean;
};
export declare const prefetchServerComponent: (_componentName: string, _componentProps: unknown, _options?: PrefetchServerComponentOptions) => Promise<void>;
//# sourceMappingURL=prefetchServerComponent.server.d.ts.map