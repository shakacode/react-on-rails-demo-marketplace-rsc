import * as React from 'react';
import { type ReactNode } from 'react';
import { ServerComponentFetchError } from './ServerComponentFetchError.ts';
/**
 * Imperative handle exposed by `<RSCRoute>` via `ref`.
 *
 * `refetch()` re-fetches the server component using the RSCRoute's currently
 * rendered `componentName` and `componentProps`. It resolves with the new
 * rendered ReactNode and rejects with `ServerComponentFetchError` if the fetch
 * fails or the RSC payload resolves to an Error object.
 *
 * In production, client-control refetch failures are recoverable: the last
 * successful route content stays visible, `refetchError` is set, and `retry()`
 * aliases `refetch()` for error UI. Both methods re-fetch the route's current
 * component name and props. If props changed after the failure, `retry()`
 * attempts the new request; call `clearRefetchError()` to dismiss the old error
 * without fetching. Outside production, failures still throw through the route
 * so development diagnostics stay loud.
 *
 * Behavior caveats:
 * - **Concurrent refetches:** only the most-recent cache write wins; earlier
 *   returned promises may resolve with stale data while the UI has already
 *   moved on to a later refetch.
 * - **Unmount:** if the owning `<RSCRoute>` unmounts before resolution, the
 *   shared cache still updates (so other RSCRoutes bound to the same key
 *   reflect the new payload) but no visible re-render happens in the
 *   unmounted instance.
 */
export type RSCRouteHandle = {
    refetch: () => Promise<ReactNode>;
    /**
     * Alias for `refetch()` for error-recovery UI. Re-fetches using the route's
     * current `componentName` and `componentProps`; if props changed after the
     * failure, `retry()` issues the new request rather than replaying the failed
     * one.
     */
    retry: () => Promise<ReactNode>;
    refetchError: ServerComponentFetchError | null;
    clearRefetchError: () => void;
};
export type RSCRouteProps = {
    componentName: string;
    componentProps: unknown;
    ssr?: boolean;
    onRefetchError?: (error: ServerComponentFetchError) => void;
};
/**
 * Returns the `RSCRouteHandle` of the nearest ancestor `<RSCRoute>`, so a
 * client component rendered inside a server component subtree can refetch
 * that server component without knowing its name or props.
 *
 * @throws If called outside of any `<RSCRoute>` ancestor.
 *
 * @example
 * ```tsx
 * function InlineRefreshButton() {
 *   const { refetch } = useCurrentRSCRoute();
 *   return <button onClick={() => refetch().catch(console.error)}>Refresh</button>;
 * }
 * ```
 */
export declare function useCurrentRSCRoute(): RSCRouteHandle;
/**
 * Renders a React Server Component inside a React Client Component.
 *
 * RSCRoute provides a bridge between client and server components, allowing server components
 * to be directly rendered inside client components. This component:
 *
 * 1. By default during initial SSR - Uses the RSC payload to render the server component and embeds the payload in the page
 * 2. During hydration - Uses the embedded RSC payload already in the page
 * 3. During client navigation - Fetches the RSC payload via HTTP
 *
 * Pass ssr={false} to skip rendering route content during streaming server rendering. When wrapped
 * in Suspense, React renders the nearest fallback in the server HTML and retries this route on the
 * client through the same RSC provider path used by the default ssr={true} mode.
 *
 * @example
 * ```tsx
 * <RSCRoute componentName="MyServerComponent" componentProps={{ user }} />
 * ```
 *
 * @important Only use for server components whose props change rarely. Frequent prop changes
 * will cause network requests for each change, impacting performance.
 *
 * @important This component expects that the component tree that contains it is wrapped using
 * wrapServerComponentRenderer from 'react-on-rails/wrapServerComponentRenderer/client' for client-side
 * rendering or 'react-on-rails/wrapServerComponentRenderer/server' for server-side rendering.
 */
declare const RSCRoute: React.ForwardRefExoticComponent<RSCRouteProps & React.RefAttributes<RSCRouteHandle>>;
export default RSCRoute;
//# sourceMappingURL=RSCRoute.d.ts.map