export { createTanStackRouterRenderFunction, serverRenderTanStackAppAsync } from './tanstack-router/index.ts';
export type { DehydratedRouterState, TanStackRouterOptions } from './tanstack-router/index.ts';
//# sourceMappingURL=tanstack-router.d.ts.map