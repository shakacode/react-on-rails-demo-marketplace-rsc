export declare const PAGE_UNLOAD_REGISTRY_ERROR_NAME = "ReactOnRailsProPageUnloadRegistryError";
export declare function isPageUnloadRegistryError(error: unknown): boolean;
export default class CallbackRegistry<T> {
    private readonly registryType;
    private registeredItems;
    private waitingPromises;
    private notUsedItems;
    private timeoutEventsInitialized;
    private timedout;
    private pageLoaded;
    private timeoutId;
    constructor(registryType: string);
    private clearPendingTimeout;
    private startTimeout;
    private triggerTimeout;
    private initializeTimeoutEvents;
    set(name: string, item: T): void;
    get(name: string): T;
    has(name: string): boolean;
    getIfExists(name: string): T | undefined;
    clear(): void;
    clearWithReject(error: Error): void;
    getAll(): Map<string, T>;
    getOrWaitForItem(name: string): Promise<T>;
    private createNotFoundError;
    private createPageUnloadError;
}
//# sourceMappingURL=CallbackRegistry.d.ts.map