export type SuccessfulVersionSnapshot = {
    key: string;
    version: number;
};
export declare const shouldClearRefetchErrorOnSuccessfulVersionChange: (previous: SuccessfulVersionSnapshot, current: SuccessfulVersionSnapshot) => boolean;
//# sourceMappingURL=RSCRouteSuccessfulVersion.d.ts.map