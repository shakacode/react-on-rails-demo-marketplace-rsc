export declare const RSC_PAYLOAD_SCRIPT_ATTRIBUTE = "data-react-on-rails-rsc-payload";
export declare const RSC_PAYLOAD_SCRIPT_ATTRIBUTE_VALUE = "true";
export declare const RSC_PAYLOAD_SCRIPT_MARKER_ATTRIBUTE = "data-react-on-rails-rsc-payload=\"true\"";
export declare const RSC_STYLESHEET_PRECEDENCE = "rsc-css";
//# sourceMappingURL=rscDomMarkers.d.ts.map