import type { ReactOnRailsInternal } from 'react-on-rails/types';
/**
 * Creates a ReactOnRails instance with Pro capabilities.
 *
 * @param additionalCapabilities - Extra capabilities to include (e.g., SSR, streaming, RSC).
 * @param currentGlobal - Current globalThis.ReactOnRails value (for misconfiguration detection).
 */
export default function createReactOnRailsPro(additionalCapabilities?: Partial<ReactOnRailsInternal>[], currentGlobal?: ReactOnRailsInternal | null): ReactOnRailsInternal;
//# sourceMappingURL=createReactOnRailsPro.d.ts.map