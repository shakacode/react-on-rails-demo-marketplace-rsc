export interface CacheEntry {
    value: Buffer[];
    revalidate: number;
    timestamp: number;
}
export interface CacheHandler {
    get(key: string): Promise<CacheEntry | null>;
    set(key: string, entry: CacheEntry): Promise<void>;
}
//# sourceMappingURL=CacheHandler.d.ts.map