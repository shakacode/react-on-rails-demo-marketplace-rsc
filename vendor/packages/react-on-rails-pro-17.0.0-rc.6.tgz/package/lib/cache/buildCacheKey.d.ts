export declare function buildCacheKey(buildId: string, id: string, args: unknown[]): string;
//# sourceMappingURL=buildCacheKey.d.ts.map