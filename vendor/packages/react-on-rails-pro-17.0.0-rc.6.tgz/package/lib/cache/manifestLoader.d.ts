import type { buildClientRenderer as buildClientRendererType } from 'react-on-rails-rsc/client.node';
type ClientRenderer = ReturnType<typeof buildClientRendererType>;
export declare function setManifestFileNames(clientManifest: string, serverClientManifest: string): void;
export declare function getClientManifestFileName(): string | undefined;
export declare function getClientRenderer(): Promise<ClientRenderer>;
export {};
//# sourceMappingURL=manifestLoader.d.ts.map