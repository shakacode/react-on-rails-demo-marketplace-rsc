export declare function setBuildId(id: string): void;
export declare function getBuildId(): string;
//# sourceMappingURL=buildIdProvider.d.ts.map