import type { CacheHandler } from './CacheHandler.ts';
export declare function registerCacheHandler(kind: string, handler: CacheHandler): void;
export declare function getCacheHandler(kind: string): CacheHandler;
//# sourceMappingURL=cacheHandlerRegistry.d.ts.map