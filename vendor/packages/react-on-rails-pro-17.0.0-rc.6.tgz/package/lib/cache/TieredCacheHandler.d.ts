import type { CacheEntry, CacheHandler } from './CacheHandler.ts';
export interface TieredCacheHandlerOptions {
    /**
     * Maximum TTL (in seconds) for entries promoted to L1.
     * Bounds how long a stale L1 entry can persist after L2 is updated by another worker.
     * Defaults to undefined (use the entry's original revalidate value).
     */
    l1MaxTtlSeconds?: number;
}
export declare class TieredCacheHandler implements CacheHandler {
    private l1;
    private l2;
    private l1MaxTtlSeconds;
    constructor(l1: CacheHandler, l2: CacheHandler, opts?: TieredCacheHandlerOptions);
    get(key: string): Promise<CacheEntry | null>;
    set(key: string, entry: CacheEntry): Promise<void>;
    private applyL1Ttl;
}
//# sourceMappingURL=TieredCacheHandler.d.ts.map