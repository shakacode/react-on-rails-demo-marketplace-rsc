import type { ReactNode } from 'react';
export interface UnstableCacheOptions {
    /** Stable identifier for this cached function. Required. */
    id: string;
    /** Time in seconds before the cache entry is considered stale. 0 = indefinite. */
    revalidate?: number;
    /** Cache handler kind to use. Defaults to 'default' (in-memory LRU). */
    kind?: string;
}
export declare function unstable_cache<TArgs extends unknown[]>(originalFn: (...args: TArgs) => Promise<ReactNode> | ReactNode, options: UnstableCacheOptions): (...args: TArgs) => Promise<ReactNode>;
//# sourceMappingURL=unstable_cache.d.ts.map