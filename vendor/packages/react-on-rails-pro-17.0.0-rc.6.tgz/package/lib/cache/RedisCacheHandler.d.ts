import type { RedisOptions } from 'ioredis';
import type { CacheEntry, CacheHandler } from './CacheHandler.ts';
export interface RedisCacheHandlerOptions {
    /** ioredis client options or a Redis URL string. Defaults to 'redis://127.0.0.1:6379'. */
    redisUrl?: string | RedisOptions;
    /** Maximum entry size in bytes. Entries larger than this are not cached. Default: 1MB. */
    maxEntryBytes?: number;
}
export declare class RedisCacheHandler implements CacheHandler {
    private redis;
    private maxEntryBytes;
    constructor(options?: RedisCacheHandlerOptions);
    get(key: string): Promise<CacheEntry | null>;
    set(key: string, entry: CacheEntry): Promise<void>;
}
//# sourceMappingURL=RedisCacheHandler.d.ts.map