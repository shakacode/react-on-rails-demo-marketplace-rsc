import type { buildServerRenderer as buildServerRendererType } from 'react-on-rails-rsc/server.node';
type ServerRenderer = ReturnType<typeof buildServerRendererType>;
export declare function getServerRenderer(): Promise<ServerRenderer>;
export {};
//# sourceMappingURL=manifestLoaderServer.d.ts.map