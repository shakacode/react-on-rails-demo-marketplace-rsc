import type { CacheEntry, CacheHandler } from './CacheHandler.ts';
export declare class InMemoryLRUCacheHandler implements CacheHandler {
    private cache;
    private maxEntries;
    constructor(maxEntries?: number);
    get(key: string): Promise<CacheEntry | null>;
    set(key: string, entry: CacheEntry): Promise<void>;
}
//# sourceMappingURL=InMemoryLRUCacheHandler.d.ts.map