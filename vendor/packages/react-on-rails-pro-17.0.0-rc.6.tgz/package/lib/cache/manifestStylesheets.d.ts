import type { BundleManifest } from 'react-on-rails-rsc';
export declare function collectRSCClientManifestStylesheetHrefs(reactClientManifest: BundleManifest): ReadonlySet<string>;
export declare function getReactClientManifest(clientManifest: string): Promise<BundleManifest>;
export declare function getRSCClientManifestStylesheetHrefs(clientManifest: string): Promise<ReadonlySet<string>>;
//# sourceMappingURL=manifestStylesheets.d.ts.map