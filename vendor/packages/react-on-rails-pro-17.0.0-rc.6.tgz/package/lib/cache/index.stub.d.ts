/**
 * Stub module for non-react-server contexts (e.g. SSR server bundle).
 *
 * The auto-load system includes .server.tsx files in both the RSC bundle
 * and the SSR server bundle. The SSR bundle never executes server component
 * code (it delegates to the RSC bundle), but webpack still needs to resolve
 * all imports at build time. This stub satisfies that requirement.
 */
import type { ReactNode } from 'react';
import type { CacheHandler, CacheEntry } from './CacheHandler.ts';
export type { CacheHandler, CacheEntry };
export interface UnstableCacheOptions {
    id: string;
    revalidate?: number;
    kind?: string;
}
export declare function unstable_cache<TArgs extends unknown[]>(originalFn: (...args: TArgs) => Promise<ReactNode> | ReactNode, options: UnstableCacheOptions): (...args: TArgs) => Promise<ReactNode>;
export declare function registerCacheHandler(kind: string, handler: CacheHandler): void;
export type { RedisCacheHandlerOptions } from './RedisCacheHandler.ts';
export type { TieredCacheHandlerOptions } from './TieredCacheHandler.ts';
export declare class RedisCacheHandler implements CacheHandler {
    constructor(_options?: unknown);
    get(_key: string): Promise<CacheEntry | null>;
    set(_key: string, _entry: CacheEntry): Promise<void>;
}
export declare class TieredCacheHandler implements CacheHandler {
    constructor(_l1: CacheHandler, _l2: CacheHandler, _opts?: unknown);
    get(_key: string): Promise<CacheEntry | null>;
    set(_key: string, _entry: CacheEntry): Promise<void>;
}
//# sourceMappingURL=index.stub.d.ts.map