export declare const REACT_ON_RAILS_PERFORMANCE_MARKS_QUEUE = "REACT_ON_RAILS_PERFORMANCE_MARKS";
export declare const RSC_STREAM_PERFORMANCE_MARK_PREFIX = "react-on-rails:rsc";
export type BrowserPerformanceMarkDetail = Record<string, unknown>;
export type BrowserPerformanceMarkFallback = 'mark-detail-unavailable' | 'performance-mark-unavailable';
export type BrowserPerformanceMarkEntry = {
    name: string;
    detail: BrowserPerformanceMarkDetail;
    fallback?: BrowserPerformanceMarkFallback;
};
export declare function markBrowserPerformance(markName: string, detail: BrowserPerformanceMarkDetail): void;
export declare function createBrowserPerformanceMarkScript(markName: string, detail: BrowserPerformanceMarkDetail): string;
//# sourceMappingURL=browserPerformanceMarks.d.ts.map