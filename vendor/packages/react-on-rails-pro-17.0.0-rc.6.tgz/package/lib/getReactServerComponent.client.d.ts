import * as React from 'react';
import { RailsContext } from 'react-on-rails/types';
import type { RSCPreloadedPayloadGlobals } from './rscPayloadGlobals.ts';
declare global {
    interface Window {
        REACT_ON_RAILS_RSC_PAYLOADS?: RSCPreloadedPayloadGlobals['REACT_ON_RAILS_RSC_PAYLOADS'];
        REACT_ON_RAILS_RSC_ERRORS?: RSCPreloadedPayloadGlobals['REACT_ON_RAILS_RSC_ERRORS'];
    }
}
export type ClientGetReactServerComponentProps = {
    componentName: string;
    componentProps: unknown;
    enforceRefetch?: boolean;
};
export type FetchRSCOptions = {
    componentName: string;
    componentProps: unknown;
    rscPayloadGenerationUrlPath: string;
    cspNonce?: string;
    fetchOptions?: Pick<RequestInit, 'credentials' | 'headers' | 'signal'>;
    replayConsoleScripts?: boolean;
};
/**
 * Fetches an RSC payload via HTTP request.
 *
 * This function:
 * 1. Serializes the component props
 * 2. Makes an HTTP request to the RSC payload generation endpoint
 * 3. Processes the response stream into React elements
 *
 * This is used for client-side navigation or when rendering components
 * that weren't part of the initial server render.
 *
 * @param componentName - Name of the server component
 * @param componentProps - Props for the server component
 * @param rscPayloadGenerationUrlPath - Base Rails path where RSC payloads are fetched
 * @param cspNonce - Optional nonce for legacy console replay script injection
 * @param fetchOptions - Narrow fetch controls for callers that need credentials, headers, or cancellation
 * @param replayConsoleScripts - Whether console replay metadata should be materialized as script tags
 * @returns A Promise resolving to the rendered React element; rejects (never throws synchronously)
 * if the RSC payload generation URL path is not configured, request preparation fails, or the
 * network request fails
 * @internal Shared implementation for Pro client helpers; prefer exported package entry points.
 */
export declare const fetchRSC: ({ componentName, componentProps, rscPayloadGenerationUrlPath, cspNonce, fetchOptions, replayConsoleScripts, }: FetchRSCOptions) => Promise<React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | (string | number | bigint | boolean | React.ReactPortal | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | null | undefined)>;
/**
 * Creates React elements from preloaded RSC payloads in the page.
 *
 * This function:
 * 1. Creates a ReadableStream from the array of raw Flight data strings
 * 2. Feeds the stream directly to React's createFromReadableStream
 *
 * Console replay is handled separately via standalone <script> tags
 * emitted by injectRSCPayload, not through the payload array.
 *
 * This is used during hydration to avoid making HTTP requests when
 * the payload is already embedded in the page.
 *
 * @param payloads - Array of raw Flight data strings from the global array
 * @param componentName - Name of the server component, used for error context
 * @returns A Promise resolving to the rendered React element
 */
/** @internal Exported only for tests */
export declare const createFromPreloadedPayloads: (payloads: string[], componentName: string, getDiagnosticMetadata?: () => Record<string, unknown> | undefined) => Promise<React.ReactNode>;
/**
 * Creates a function that fetches and renders a server component on the client side.
 *
 * This style of higher-order function is necessary as the function that gets server components
 * on server has different parameters than the function that gets them on client. The environment
 * dependent parameters (domNodeId, railsContext) are passed from the `wrapServerComponentRenderer`
 * function, while the environment agnostic parameters (componentName, componentProps, enforceRefetch)
 * are passed from the RSCProvider which is environment agnostic.
 *
 * The returned function:
 * 1. Checks for embedded RSC payloads in window.REACT_ON_RAILS_RSC_PAYLOADS using the domNodeId
 * 2. If found, uses the embedded payload to avoid an HTTP request
 * 3. If not found (during client navigation or dynamic rendering), fetches via HTTP
 * 4. Processes the RSC payload into React elements
 *
 * The embedded payload approach ensures optimal performance during initial page load,
 * while the HTTP fallback enables dynamic rendering after navigation.
 *
 * @param domNodeId - The DOM node ID to create a unique key for the RSC payload store
 * @param railsContext - Context for the current request, shared across all components
 * @returns A function that accepts RSC parameters and returns a Promise resolving to the rendered React element
 *
 * The returned function accepts:
 * @param componentName - Name of the server component to render
 * @param componentProps - Props to pass to the server component
 * @param enforceRefetch - Whether to enforce a refetch of the component
 *
 * @important This is an internal function. End users should not use this directly.
 * Instead, use the useRSC hook which provides getComponent and refetchComponent functions
 * for fetching or retrieving cached server components. For rendering server components,
 * consider using RSCRoute component which handles the rendering logic automatically.
 */
declare const getReactServerComponent: (domNodeId: string, railsContext: RailsContext) => ({ componentName, componentProps, enforceRefetch }: ClientGetReactServerComponentProps) => Promise<React.ReactNode>;
export default getReactServerComponent;
//# sourceMappingURL=getReactServerComponent.client.d.ts.map