/**
 * Single source of truth for the page-scoped RSC globals that injected payload
 * `<script>` tags populate during server-streamed hydration (see injectRSCPayload.ts).
 *
 * Two places consume this shape and must stay in lockstep:
 * - the `Window` augmentation in getReactServerComponent.client.ts (read side), and
 * - the navigation-teardown cleanup in ClientSideRenderer.ts (`unmountAll`, delete side).
 *
 * Declaring the shape here once — rather than copying it into each file — keeps them
 * from drifting if a global's value type changes or a new RSC global is added.
 */
export type RSCPreloadedPayloadGlobals = {
    REACT_ON_RAILS_RSC_PAYLOADS: Record<string, string[]>;
    REACT_ON_RAILS_RSC_ERRORS: Record<string, Record<string, unknown>>;
};
//# sourceMappingURL=rscPayloadGlobals.d.ts.map