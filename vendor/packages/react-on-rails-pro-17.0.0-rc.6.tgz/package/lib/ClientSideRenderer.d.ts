export declare function renderOrHydrateComponent(domIdOrElement: string | Element): Promise<void>;
export declare const renderOrHydrateCompleteComponents: () => Promise<void>;
export declare const renderOrHydrateAllComponents: () => Promise<void>;
export declare function hydrateStore(storeNameOrElement: string | Element): Promise<void>;
export declare const hydrateCompleteStores: () => Promise<void>;
export declare const hydrateAllStores: () => Promise<void>;
export declare function unmountAll(): void;
//# sourceMappingURL=ClientSideRenderer.d.ts.map