import { type BrowserPerformanceMarkDetail } from './browserPerformanceMarks.ts';
export declare const RSC_HYDRATION_START_MARK = "react-on-rails:rsc:hydration:start";
export declare const RSC_HYDRATION_INTERACTIVE_MARK = "react-on-rails:rsc:hydration:interactive";
type RSCClientHydrationMode = 'hydrate' | 'render';
type RSCClientHydrationBoundary = 'server-component-root';
export type RSCClientHydrationMarkDetail = BrowserPerformanceMarkDetail & {
    source: 'react-on-rails-pro';
    componentName: string;
    domNodeId: string;
    mode: RSCClientHydrationMode;
    boundary: RSCClientHydrationBoundary;
};
export declare function createRSCClientHydrationMarkDetail({ componentName, domNodeId, mode, boundary, }: {
    componentName: string;
    domNodeId: string;
    mode: RSCClientHydrationMode;
    boundary: RSCClientHydrationBoundary;
}): RSCClientHydrationMarkDetail;
export declare function markRSCClientHydrationStart(detail: RSCClientHydrationMarkDetail): void;
export declare function scheduleRSCClientHydrationInteractiveMark(detail: RSCClientHydrationMarkDetail): () => void;
export {};
//# sourceMappingURL=rscClientPerformanceMarks.d.ts.map