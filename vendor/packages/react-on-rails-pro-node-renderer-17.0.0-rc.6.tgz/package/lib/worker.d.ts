import { Transform } from 'stream';
import { Config } from './shared/configBuilder.js';
import type { FastifyReply } from './worker/types.js';
import type { ExecutionContext } from './worker/vm.js';
import { ResponseResult, Asset } from './shared/utils.js';
export { configureFastify, type FastifyConfigFunction } from './worker/fastifyConfig.js';
declare module '@fastify/multipart' {
    interface MultipartFile {
        value: Asset;
    }
}
declare module 'fastify' {
    interface FastifyRequest {
        uploadDir: string;
        uploadAssetValidationError: string | null;
        uploadAuthenticationError: ResponseResult | null;
        uploadBodyLimitExceeded: boolean;
    }
}
/** @internal Used in tests */
export declare function releaseExecutionContextWhenStreamFinishes(stream: NonNullable<ResponseResult['stream']>, res: FastifyReply, executionContext: ExecutionContext): {
    release: () => void;
    stream: Transform;
};
export declare const disableHttp2: () => void;
export default function run(config: Partial<Config>): import("fastify").FastifyInstance<import("http2").Http2Server<typeof import("http").IncomingMessage, typeof import("http").ServerResponse, typeof import("http2").Http2ServerRequest, typeof import("http2").Http2ServerResponse>, import("http2").Http2ServerRequest, import("http2").Http2ServerResponse<import("http2").Http2ServerRequest>, import("fastify").FastifyBaseLogger, import("fastify").FastifyTypeProviderDefault> & PromiseLike<import("fastify").FastifyInstance<import("http2").Http2Server<typeof import("http").IncomingMessage, typeof import("http").ServerResponse, typeof import("http2").Http2ServerRequest, typeof import("http2").Http2ServerResponse>, import("http2").Http2ServerRequest, import("http2").Http2ServerResponse<import("http2").Http2ServerRequest>, import("fastify").FastifyBaseLogger, import("fastify").FastifyTypeProviderDefault>> & {
    __linterBrands: "SafePromiseLike";
};
//# sourceMappingURL=worker.d.ts.map