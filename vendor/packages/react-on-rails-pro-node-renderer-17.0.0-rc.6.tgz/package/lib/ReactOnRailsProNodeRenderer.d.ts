import { Config } from './shared/configBuilder.js';
export declare function parseWorkersCount(value: string | null | undefined): number | null;
export declare function reactOnRailsProNodeRenderer(config?: Partial<Config>): Promise<void>;
//# sourceMappingURL=ReactOnRailsProNodeRenderer.d.ts.map