import type { Attributes } from '@opentelemetry/api';
import type { SpanExporter, SpanProcessor } from '@opentelemetry/sdk-trace-base';
declare module '../shared/tracing.js' {
    interface UnitOfWorkOptions {
        opentelemetry?: {
            name: string;
            attributes?: Attributes;
        };
    }
}
export interface OpenTelemetryInitOptions {
    /** Service name reported in traces. Defaults to "react-on-rails-pro-node-renderer".
     *  `OTEL_SERVICE_NAME` env var takes precedence over this value. If neither is
     *  set, `resourceAttributes["service.name"]` or `OTEL_RESOURCE_ATTRIBUTES`
     *  can override the default service name. */
    serviceName?: string;
    /** Register HTTP + Fastify auto-instrumentation. Default: false.
     *  OpenTelemetry module patches are process-global and cannot be rolled back;
     *  if later init steps fail, patched modules remain installed with a no-op tracer. */
    fastify?: boolean;
    /** Wrap SSR work in spans via setupTracing + setupSubSpan. Default: false. */
    tracing?: boolean;
    /** Override the default OTLP HTTP exporter. */
    exporter?: SpanExporter;
    /** Override the default span processor.
     *  Default: BatchSpanProcessor in production, SimpleSpanProcessor otherwise. */
    spanProcessor?: SpanProcessor;
    /** Additional resource attributes merged into the default resource. */
    resourceAttributes?: Record<string, string>;
    /** Maximum time to wait for provider.shutdown() during Fastify onClose. Default: 5000ms. */
    shutdownTimeoutMs?: number;
}
export declare function init(opts?: OpenTelemetryInitOptions): void;
//# sourceMappingURL=opentelemetry.d.ts.map