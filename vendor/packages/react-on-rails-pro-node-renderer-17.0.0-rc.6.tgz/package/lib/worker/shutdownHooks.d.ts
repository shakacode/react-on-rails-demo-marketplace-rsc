export type WorkerShutdownHook = () => void | Promise<void>;
/**
 * Upper bound on how long the worker waits for all registered shutdown hooks
 * to settle before forcibly destroying the worker. Integration shutdown
 * timeouts (e.g. OpenTelemetry `shutdownTimeoutMs`) must stay below this so
 * the worker doesn't kill an in-flight hook before it finishes flushing.
 */
export declare const WORKER_SHUTDOWN_HOOKS_TIMEOUT_MS = 10000;
export declare function registerWorkerShutdownHook(hook: WorkerShutdownHook): () => void;
export declare function runWorkerShutdownHooks(): Promise<void>;
export declare function __resetWorkerShutdownHooksForTest(): void;
//# sourceMappingURL=shutdownHooks.d.ts.map