import type { FastifyInstance } from './types.js';
export type FastifyConfigFunction = (app: FastifyInstance) => void;
/**
 * Configures the Fastify instance before starting the server.
 *
 * This module intentionally has no runtime dependency on `worker.ts` or
 * `fastify`, so integrations can register instrumentation before Fastify is
 * required by the worker module graph.
 */
export declare function registerFastifyConfigFunction(configFunction: FastifyConfigFunction): () => void;
/**
 * Public one-way registration API for custom entrypoints and integrations.
 * Internal callers use registerFastifyConfigFunction() when they need the
 * unregister callback during failed initialization or shutdown cleanup.
 */
export declare function configureFastify(configFunction: FastifyConfigFunction): void;
export declare function applyFastifyConfigFunctions(app: FastifyInstance): void;
export declare function __resetFastifyConfigFunctionsForTest(): void;
//# sourceMappingURL=fastifyConfig.d.ts.map