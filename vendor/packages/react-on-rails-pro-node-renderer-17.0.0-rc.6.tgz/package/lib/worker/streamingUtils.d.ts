export declare function formatPropRequestChunk(propName: string): Buffer;
export declare function formatRenderCompleteChunk(): Buffer;
//# sourceMappingURL=streamingUtils.d.ts.map