export interface AuthBody {
    password?: string;
}
export declare function authenticate(body: AuthBody): {
    headers: {
        'Cache-Control': string;
    };
    status: number;
    data: string;
} | undefined;
//# sourceMappingURL=authHandler.d.ts.map