export type StartupListenErrorHandlerOptions = {
    err: Error;
    host: string;
    port: number;
    isWorker?: boolean;
    send?: NodeJS.Process['send'];
    exit?: NodeJS.Process['exit'];
};
export declare function handleStartupListenError({ err, host, port, isWorker, send, exit, }: StartupListenErrorHandlerOptions): void;
//# sourceMappingURL=startupErrorHandler.d.ts.map