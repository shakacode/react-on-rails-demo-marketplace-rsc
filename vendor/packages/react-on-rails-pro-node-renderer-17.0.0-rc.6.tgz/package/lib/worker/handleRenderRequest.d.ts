import { Asset, ResponseResult, type RequestInfo } from '../shared/utils.js';
import { type TracingContext } from '../shared/tracing.js';
import { ExecutionContext } from './vm.js';
export declare function sumUploadedBytes(assets: Asset[]): Promise<number>;
export type ProvidedNewBundle = {
    timestamp: string | number;
    bundle: Asset;
};
export declare function escapeServerTimingDescription(description: string): string;
/** Adds renderer prepare Server-Timing to streamed responses when enabled. */
export declare function addRendererServerTiming(response: ResponseResult, startedAtMs: number, enabled: boolean): void;
export declare function handleNewBundlesProvided(requestContext: RequestInfo, providedNewBundles: ProvidedNewBundle[], assetsToCopy: Asset[] | null | undefined): Promise<ResponseResult | undefined>;
/**
 * Creates the result for the Fastify server to use.
 * @returns Promise where the result contains { status, data, headers } to
 * send back to the browser.
 */
export declare function handleRenderRequest({ renderingRequest, bundleTimestamp, dependencyBundleTimestamps, providedNewBundles, assetsToCopy, rscStreamObservability, tracingContext, }: {
    renderingRequest: string;
    bundleTimestamp: string | number;
    dependencyBundleTimestamps?: string[] | number[];
    providedNewBundles?: ProvidedNewBundle[] | null;
    assetsToCopy?: Asset[] | null;
    rscStreamObservability?: boolean;
    tracingContext?: TracingContext;
}): Promise<{
    response: ResponseResult;
    executionContext?: ExecutionContext;
}>;
//# sourceMappingURL=handleRenderRequest.d.ts.map