export default function logLicenseStatus(licenseToken?: string): void;
//# sourceMappingURL=logLicenseStatus.d.ts.map