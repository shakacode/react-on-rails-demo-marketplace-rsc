import type { NodeTracerProvider as NodeTracerProviderType } from '@opentelemetry/sdk-trace-node';
export declare function getOpenTelemetryTracerProvider(): NodeTracerProviderType | null;
/**
 * Updates the process-global OpenTelemetry provider reference.
 *
 * Caller contract: only integrations that own the OpenTelemetry init/shutdown
 * lifecycle should call this, and the value must mirror that lifecycle's
 * current provider ownership.
 */
export declare function setOpenTelemetryTracerProvider(provider: NodeTracerProviderType | null): void;
//# sourceMappingURL=opentelemetryState.d.ts.map