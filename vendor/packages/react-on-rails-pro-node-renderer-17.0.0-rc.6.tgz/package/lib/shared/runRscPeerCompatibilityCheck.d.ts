export interface RunRscPeerCompatibilityCheckOptions {
    cwd?: string;
    proVersion?: string;
    env?: NodeJS.ProcessEnv;
    resolveVersion?: (packageName: string) => string | null;
}
export declare function runRscPeerCompatibilityCheck(options?: RunRscPeerCompatibilityCheckOptions): void;
//# sourceMappingURL=runRscPeerCompatibilityCheck.d.ts.map