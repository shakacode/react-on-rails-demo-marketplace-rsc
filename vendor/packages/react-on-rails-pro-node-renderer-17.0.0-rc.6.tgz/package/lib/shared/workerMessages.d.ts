export declare const WORKER_STARTUP_FAILURE: "NODE_RENDERER_WORKER_STARTUP_FAILURE";
export interface WorkerStartupFailureMessage {
    type: typeof WORKER_STARTUP_FAILURE;
    stage: 'listen';
    code?: string;
    errno?: number;
    syscall?: string;
    host: string;
    port: number;
    message: string;
}
export declare function isWorkerStartupFailureMessage(value: unknown): value is WorkerStartupFailureMessage;
//# sourceMappingURL=workerMessages.d.ts.map