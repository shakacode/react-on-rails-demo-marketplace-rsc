/**
 * This contains the options necessary to start a unit of work (transaction/span/etc.).
 * Integrations should augment it using their name as the property.
 *
 * For example, in Sentry SDK v7+ the unit of work is a `Span`, and `Sentry.startSpan` takes `StartSpanOptions`,
 * so that integration adds `{ sentry?: StartSpanOptions }`.
 * In v6, the unit of work is a `Transaction`, and `Sentry.startTransaction` takes `TransactionContext`,
 * so that integration adds `{ sentry6?: TransactionContext }`.
 */
export interface UnitOfWorkOptions {
}
/**
 * Passed to the callback function executed by {@link trace}.
 * This is only used (and augmented) by integrations that need to associate error reports with units of work manually.
 *
 * For example, Sentry SDK v7+ stores the active span in an {@link AsyncLocalStorage} and
 * it's automatically provided to `Sentry.capture...` methods, so it doesn't use this.
 * But v6 needs to include the active transaction in those methods'
 * {@link import('@sentry/types').CaptureContext} parameter, and so it adds `{ sentry6: CaptureContext }`.
 */
export interface TracingContext {
}
type UnitOfWork<T> = (tracingContext?: TracingContext) => Promise<T>;
type Executor = <T>(fn: UnitOfWork<T>, unitOfWorkOptions: UnitOfWorkOptions) => Promise<T>;
/**
 * Data describing an SSR request.
 */
interface SsrRequestData {
    renderingRequest: string;
}
type StartSsrRequestOptions = (request: SsrRequestData) => UnitOfWorkOptions;
export declare const startSsrRequestOptions: StartSsrRequestOptions;
/**
 * Options for {@link trace}.
 */
export interface TracingIntegrationOptions {
    executor: Executor;
    startSsrRequestOptions?: StartSsrRequestOptions;
}
/**
 * Sets up tracing for the given integration.
 * @param options.executor - A function that wraps an async callback in the tracing service's unit of work.
 * @param options.startSsrRequestOptions - Options used to start a new unit of work for an SSR request.
 *   Should be an object with your integration name as the only property.
 *   It will be passed to the executor.
 * @returns true when this call installed the tracing integration.
 */
export declare function setupTracing(options: TracingIntegrationOptions): boolean;
/**
 * Reports a unit of work to the tracing service, if any.
 */
export declare function trace<T>(fn: UnitOfWork<T>, unitOfWorkOptions: UnitOfWorkOptions): Promise<T>;
/**
 * Resets the installed tracing executor + startSsrRequestOptions back to
 * defaults. Integrations use this during lifecycle teardown or failed initialization cleanup.
 *
 * Caller contract: only integrations that own the active tracing lifecycle
 * should call this, and only while tearing that lifecycle down.
 */
export declare function resetTracing(): void;
/**
 * Test-only: reset the installed tracing executor + startSsrRequestOptions back
 * to defaults. Not part of the public api — do not re-export from
 * `integrations/api.ts`.
 */
export declare function __resetTracingForTest(): void;
/**
 * Options passed to a sub-span wrapper.
 *
 * `name` is the span name (use dot.namespaced form, e.g. `ror.bundle.upload`).
 * `attributes` are arbitrary key/value pairs attached to the span at creation.
 */
export interface SubSpanOptions {
    name: string;
    attributes?: Record<string, string | number | boolean>;
}
/**
 * Handed to the wrapped function so it can record attributes that are only
 * known after the work runs (e.g., response byte counts). Implementations
 * forward calls to the underlying span; the no-op default discards them.
 *
 * Only include byte counts, hashes, and counts here — never raw request or
 * response payloads. Span attributes are not redacted by the renderer's
 * logging policy.
 */
export interface SubSpanController {
    setAttributes(attributes: Record<string, string | number | boolean>): void;
}
/**
 * Signature of a sub-span implementation installed via {@link setupSubSpan}.
 * Must invoke `fn(controller)` and return its result. May wrap `fn` in a
 * tracing span. The implementation supplies a controller that forwards
 * `setAttributes` to the span; pass a no-op controller (e.g.
 * `{ setAttributes() {} }`) when no span is being created.
 *
 * Implementations must either invoke `fn` synchronously or not invoke it at
 * all before throwing/rejecting. Deferred invocation, such as scheduling `fn`
 * with `setImmediate`, is unsupported because the fallback may run `fn`
 * itself to preserve renderer behavior when an implementation fails before
 * invocation.
 */
export type SubSpanFn = <T>(opts: SubSpanOptions, fn: (controller: SubSpanController) => Promise<T>) => Promise<T>;
/**
 * Install a sub-span implementation. Integrations call this from their `init()`
 * to start receiving sub-span events. If never called, sub-spans are no-ops.
 * @returns true when this call installed the sub-span integration.
 */
export declare function setupSubSpan(impl: SubSpanFn): boolean;
/**
 * Wrap an async function in a named sub-span. Safe to call even when no
 * integration is installed — defaults to passing through to `fn`.
 *
 * The wrapped function receives a {@link SubSpanController} it can use to
 * attach attributes that are only known after the work runs (e.g., response
 * byte counts). With no integration installed, attribute updates are dropped.
 *
 * If the installed implementation throws or rejects before invoking `fn`, the
 * caller is shielded: `fn` is still executed outside any sub-span (with the
 * no-op controller) and its result returned. If the implementation fails
 * after invoking `fn`, the error is rethrown so `fn` is never run twice.
 */
export declare function subSpan<T>(opts: SubSpanOptions, fn: (controller: SubSpanController) => Promise<T>): Promise<T>;
/**
 * Resets the installed sub-span implementation back to the default pass-through.
 * Integrations use this during lifecycle teardown or failed initialization cleanup.
 *
 * Caller contract: only integrations that own the active sub-span lifecycle
 * should call this, and only while tearing that lifecycle down.
 */
export declare function resetSubSpan(): void;
/**
 * Test-only: reset the installed sub-span implementation back to the default
 * pass-through. Not part of the public api — do not re-export from
 * `integrations/api.ts`.
 */
export declare function __resetSubSpanForTest(): void;
export {};
//# sourceMappingURL=tracing.d.ts.map