import { MultipartFile } from '@fastify/multipart';
import { MoveOptions, CopyOptions } from 'fs-extra';
import { Readable, Writable, PassThrough } from 'stream';
import type { TracingContext } from './tracing.js';
import type { RenderResult } from '../worker/vm.js';
import { remapStackTrace } from '../worker/vmSourceMapSupport.js';
export declare const TRUNCATION_FILLER = "\n... TRUNCATED ...\n";
export declare const SHUTDOWN_WORKER_MESSAGE = "NODE_RENDERER_SHUTDOWN_WORKER";
export declare const SHUTDOWN_WORKER_ACK_MESSAGE = "NODE_RENDERER_SHUTDOWN_WORKER_ACK";
export declare function workerIdLabel(): number | "NO WORKER ID";
export declare function smartTrim(value: unknown, maxLength?: number): string | null;
export interface ResponseResult {
    headers: {
        'Cache-Control'?: string;
        'Content-Type'?: string;
        'X-Content-Type-Options'?: string;
        [key: string]: string | undefined;
    };
    status: number;
    data?: unknown;
    stream?: Readable;
}
export declare function badRequestResponseResult(msg: string): ResponseResult;
export declare function errorResponseResult(msg: string, tracingContext?: TracingContext): ResponseResult;
export type RequestInfo = {
    renderingRequest: string;
} | {
    label: string;
    content: string;
};
/**
 * @param request Either a rendering request (auto-labeled) or a { label, content } pair
 * @param error The error that was thrown (typed as `unknown` to minimize casts in `catch`)
 * @param context Optional context to include in the error message
 * @param stackRemapper Defaults to scanning registered source-map bundles. VM request paths pass a
 * registration-scoped remapper to avoid rewriting unrelated bundle paths.
 */
export declare function formatExceptionMessage(request: RequestInfo, error: unknown, context?: string, stackRemapper?: typeof remapStackTrace): string;
export declare function validateAssetFilename(filename: unknown): string;
export declare function saveMultipartFile(multipartFile: MultipartFile, destinationPath: string): Promise<void>;
export interface Asset {
    type: 'asset';
    savedFilePath: string;
    filename: string;
}
export declare function moveUploadedAsset(asset: Asset, destinationPath: string, options?: MoveOptions): Promise<void>;
export declare function copyUploadedAsset(asset: Asset, destinationPath: string, options?: CopyOptions): Promise<void>;
export declare function copyUploadedAssets(uploadedAssets: Asset[], targetDirectory: string): Promise<void>;
export declare function isPromise<T>(value: T | Promise<T>): value is Promise<T>;
export declare const isReadableStream: (stream: unknown) => stream is Readable;
/**
 * Pipes source to destination with proper 'close' event handling.
 *
 * Node.js `pipe()` does NOT end the destination when the source is destroyed —
 * it silently unpipes, leaving the destination open forever. This function fills
 * that gap by listening for the 'close' event (which fires after both normal
 * 'end' and `destroy()`) and ending the destination if needed.
 *
 * An optional `onError` callback provides observability for source stream errors
 * without forwarding them to the destination (which would break the pipe).
 */
export declare const safePipe: <T extends Writable>(source: Readable, destination: T, onError?: (err: Error) => void) => T;
export declare const handleStreamError: (stream: Readable, onError: (error: Error) => void) => PassThrough;
export declare const isErrorRenderResult: (result: RenderResult) => result is {
    exceptionMessage: string;
};
export declare const majorVersion: (version: string) => number;
export declare const delay: (milliseconds: number) => Promise<unknown>;
export declare function getBundleDirectory(bundleTimestamp: string | number): string;
export declare function getRequestBundleFilePath(bundleTimestamp: string | number): string;
export declare function getAssetPath(bundleTimestamp: string | number, filename: string): string;
export declare function validateBundlesExist(bundleTimestamp: string | number, dependencyBundleTimestamps?: (string | number)[]): Promise<ResponseResult | null>;
//# sourceMappingURL=utils.d.ts.map