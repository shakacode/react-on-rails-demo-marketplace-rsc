export type RscPeerCheckResult = {
    level: 'ok';
    message?: undefined;
} | {
    level: 'error';
    message: string;
};
export interface RscPeerCheckInput {
    rscVersion: string | null;
    reactVersion: string | null;
    reactDomVersion?: string | null;
    proVersion?: string;
}
export declare function checkRscPeerCompatibility(input: RscPeerCheckInput): RscPeerCheckResult;
//# sourceMappingURL=checkRscPeerCompatibility.d.ts.map