export declare const SENSITIVE_REQUEST_BODY_KEYS: Set<string>;
export declare function sanitizeBodyKeys(body: object): string[];
//# sourceMappingURL=sensitiveKeys.d.ts.map