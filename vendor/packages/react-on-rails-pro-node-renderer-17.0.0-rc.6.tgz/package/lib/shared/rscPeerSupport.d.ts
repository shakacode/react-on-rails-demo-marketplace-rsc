export declare const RSC_PEER_SUPPORT: {
    readonly reactOnRailsRsc: {
        readonly minimumVersion: "19.2.1";
        readonly minimumPrereleaseVersion: "19.2.1-rc.0";
        readonly supportedMajor: 19;
    };
    readonly react: {
        readonly supportedMajor: 19;
        readonly supportedRanges: readonly [{
            readonly rscMinor: 2;
            readonly minor: 2;
            readonly minPatch: 7;
        }];
    };
};
//# sourceMappingURL=rscPeerSupport.d.ts.map