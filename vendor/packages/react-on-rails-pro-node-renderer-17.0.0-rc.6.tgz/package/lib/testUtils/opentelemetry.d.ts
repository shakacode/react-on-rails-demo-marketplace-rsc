export declare function resetOpenTelemetryForTest(): Promise<void>;
//# sourceMappingURL=opentelemetry.d.ts.map