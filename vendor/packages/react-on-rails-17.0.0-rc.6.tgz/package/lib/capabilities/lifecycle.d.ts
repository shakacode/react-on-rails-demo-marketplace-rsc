/**
 * Core lifecycle capability.
 * Provides the core (non-Pro) implementations for page/component loaded callbacks.
 */
export declare function createLifecycleCapability(): {
    reactOnRailsPageLoaded(): Promise<void>;
    reactOnRailsComponentLoaded(domId: string): Promise<void>;
};
//# sourceMappingURL=lifecycle.d.ts.map