import type { ReactElement } from 'react';
import type { RegisteredComponent, RenderReturnType, RegisteredComponentValue, AuthenticityHeaders, Store, StoreGenerator, ReactOnRailsOptions } from '../types/index.ts';
type RegisteredComponentEntry = RegisteredComponent<RegisteredComponentValue>;
export interface Registries {
    ComponentRegistry: {
        register: (components: Record<string, RegisteredComponentValue>) => void;
        get: (name: string) => RegisteredComponentEntry;
        components: () => Map<string, RegisteredComponentEntry>;
    };
    StoreRegistry: {
        register: (storeGenerators: Record<string, StoreGenerator>) => void;
        getStore: (name: string, throwIfMissing?: boolean) => Store | undefined;
        getStoreGenerator: (name: string) => StoreGenerator;
        setStore: (name: string, store: Store) => void;
        clearHydratedStores: () => void;
        clearStoreGenerators: () => void;
        storeGenerators: () => Map<string, StoreGenerator>;
        stores: () => Map<string, Store>;
    };
}
/**
 * Creates the core capability containing all base ReactOnRails methods.
 * These are the methods that exist in every bundle variant (client, full, node, RSC).
 */
export declare function createCoreCapability(registries: Registries): {
    options: Partial<ReactOnRailsOptions>;
    isRSCBundle: boolean;
    authenticityToken(): string | null;
    authenticityHeaders(otherHeaders?: Record<string, string>): AuthenticityHeaders;
    reactHydrateOrRender(domNode: Element, reactElement: ReactElement, hydrate: boolean): RenderReturnType;
    setOptions(newOptions: Partial<ReactOnRailsOptions>): void;
    option<K extends keyof ReactOnRailsOptions>(key: K): ReactOnRailsOptions[K];
    buildConsoleReplay(): string;
    getConsoleReplayScript(): string;
    resetOptions(): void;
    register(components: Record<string, RegisteredComponentValue>): void;
    registerStore(stores: Record<string, StoreGenerator>): void;
    registerStoreGenerators(storeGenerators: Record<string, StoreGenerator>): void;
    getStore(name: string, throwIfMissing?: boolean): Store | undefined;
    getStoreGenerator(name: string): StoreGenerator;
    setStore(name: string, store: Store): void;
    clearHydratedStores(): void;
    clearStoreGenerators(): void;
    getComponent(name: string): RegisteredComponentEntry;
    registeredComponents(): Map<string, RegisteredComponentEntry>;
    storeGenerators(): Map<string, StoreGenerator>;
    stores(): Map<string, Store>;
    render(name: string, props: Record<string, unknown>, domNodeId: string, hydrate: boolean): RenderReturnType;
    serverRenderReactComponent(...args: any[]): any;
    handleError(...args: any[]): any;
    prepareRenderResult(...args: any[]): any;
    getOrWaitForComponent(): Promise<RegisteredComponentEntry>;
    getOrWaitForStore(): Promise<Store>;
    getOrWaitForStoreGenerator(): Promise<StoreGenerator>;
    reactOnRailsStoreLoaded(): Promise<void>;
    streamServerRenderedReactComponent(...args: any[]): any;
    serverRenderRSCReactComponent(...args: any[]): any;
    addAsyncPropsCapabilityToComponentProps(...args: any[]): any;
    getOrCreateAsyncPropsManager(...args: any[]): any;
};
export {};
//# sourceMappingURL=core.d.ts.map