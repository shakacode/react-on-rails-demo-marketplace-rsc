import type { RenderParams, ErrorOptions, RenderingError } from '../types/index.ts';
/**
 * SSR capability.
 * Provides server-side rendering methods (serverRenderReactComponent, handleError).
 */
export declare function createSSRCapability(): {
    handleError(options: ErrorOptions): string | undefined;
    serverRenderReactComponent(options: RenderParams): null | string | Promise<string>;
    prepareRenderResult(html: string, consoleReplayScript: string, hasErrors: boolean, renderingError: RenderingError | null): string;
};
//# sourceMappingURL=ssr.d.ts.map