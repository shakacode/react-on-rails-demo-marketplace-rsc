/**
 * SSR capability for RSC bundles.
 * SSR methods throw because they are not supported in the RSC bundle.
 */
export declare function createSSRCapability(): {
    handleError(): never;
    serverRenderReactComponent(): never;
    prepareRenderResult(): never;
};
//# sourceMappingURL=ssr.rsc.d.ts.map