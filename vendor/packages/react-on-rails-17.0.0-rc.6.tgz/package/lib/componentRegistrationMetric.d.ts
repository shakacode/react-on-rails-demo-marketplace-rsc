import type { RegisteredComponentValue } from './types/index.ts';
type RegistrationMetric = {
    label: string;
    value: number;
};
export default function componentRegistrationMetric(component: RegisteredComponentValue): RegistrationMetric;
export {};
//# sourceMappingURL=componentRegistrationMetric.d.ts.map