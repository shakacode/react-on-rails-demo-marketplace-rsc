import type { RenderParams } from './types/index.ts';
declare function serverRenderReactComponentInternal(options: RenderParams): null | string | Promise<string>;
declare const serverRenderReactComponent: typeof serverRenderReactComponentInternal;
export default serverRenderReactComponent;
//# sourceMappingURL=serverRenderReactComponent.d.ts.map