/**
 * Narrows an unknown value to a thenable (has a callable `.then`) without assuming a native
 * Promise. Shared by the core ClientRenderer, rootErrorHandlers, and the Pro ClientSideRenderer
 * (via `react-on-rails/@internal/isThenable`) so non-native thenables are handled identically
 * everywhere.
 */
export declare function isThenable(value: unknown): value is PromiseLike<unknown>;
//# sourceMappingURL=isThenable.d.ts.map