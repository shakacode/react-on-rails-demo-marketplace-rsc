declare const scriptSanitizedVal: (val: string) => string;
export default scriptSanitizedVal;
//# sourceMappingURL=scriptSanitizedVal.d.ts.map