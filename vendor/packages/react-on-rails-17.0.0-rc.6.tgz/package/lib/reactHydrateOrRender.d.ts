import type { ReactElement } from 'react';
import type { RenderReturnType } from './types/index.ts';
import type { ReactHydrateOptions } from './reactApis.cts';
export default function reactHydrateOrRender(domNode: Element, reactElement: ReactElement, hydrate: boolean, hydrateOptions?: ReactHydrateOptions): RenderReturnType;
//# sourceMappingURL=reactHydrateOrRender.d.ts.map