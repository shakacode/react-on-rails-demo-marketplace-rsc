import type { RendererTeardownResult } from './types/index.ts';
export declare function isRendererTeardownResult(value: unknown): value is RendererTeardownResult;
//# sourceMappingURL=rendererTeardown.d.ts.map