import type { RegisteredComponentValue, RenderFunction, RendererFunction } from './types/index.ts';
type AnyRenderFunction = RenderFunction | RendererFunction;
/**
 * Used to determine whether we'll call React.createElement on the component or if this is a
 * Render-Function used to return a function that takes props to return a React element
 * @param component
 * @returns {boolean}
 */
export default function isRenderFunction(component: RegisteredComponentValue): component is AnyRenderFunction;
export {};
//# sourceMappingURL=isRenderFunction.d.ts.map