import type { RegisteredComponent, RegisteredComponentValue, RenderingError, FinalHtmlResult } from './types/index.ts';
export { convertToError } from './errorUtils.ts';
/**
 * Builds the metadata object for the length-prefixed streaming protocol.
 * This is the shared metadata builder used by both streaming and non-streaming paths.
 * It contains everything EXCEPT the html content, which travels as raw bytes.
 */
type RenderMetadataSource = {
    clientProps?: Record<string, unknown>;
    hasErrors?: boolean;
    error?: RenderingError;
    isShellReady?: boolean;
};
export declare function buildRenderMetadata(consoleReplayScript: string, renderState: RenderMetadataSource): Record<string, unknown>;
/**
 * Builds a length-prefixed result string from html content and render state.
 * Format: <metadata JSON>\t<content byte length hex>\n<raw html content>
 *
 * Used by the non-streaming rendering path. The streaming path uses
 * buildRenderMetadata directly with Buffer operations for efficiency.
 */
export declare function buildLengthPrefixedResult(html: FinalHtmlResult | null, consoleReplayScript: string, renderState: RenderMetadataSource): string;
export declare function validateComponent(componentObj: RegisteredComponent<RegisteredComponentValue>, componentName: string): void;
//# sourceMappingURL=serverRenderUtils.d.ts.map