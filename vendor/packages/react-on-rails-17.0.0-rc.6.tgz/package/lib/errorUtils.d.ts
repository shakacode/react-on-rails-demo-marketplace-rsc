import type { RenderingError } from './types/index.ts';
export declare function remapSourceMappedStack(stack: RenderingError['stack']): string | undefined;
export declare function convertToError(e: unknown): Error;
//# sourceMappingURL=errorUtils.d.ts.map