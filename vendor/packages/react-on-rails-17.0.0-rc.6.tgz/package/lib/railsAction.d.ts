export type RailsActionMethod = 'POST' | 'PUT' | 'PATCH' | 'DELETE' | 'post' | 'put' | 'patch' | 'delete';
export type RailsActionPath<TVariables> = string | ((variables: TVariables) => string);
export interface RailsActionOptions<TVariables> {
    path: RailsActionPath<TVariables>;
    method?: RailsActionMethod;
    /**
     * Maps variables to the JSON request body. Omit to send variables verbatim;
     * supply `() => null` to send no body when variables only populate the path.
     * DELETE requests never send a body; identify the resource in the URL instead.
     */
    body?: (variables: TVariables) => unknown;
    /**
     * Additional request headers. `X-CSRF-Token`, `X-Requested-With`, and the JSON-body
     * `Content-Type` are controlled by this helper. `Accept` defaults to `application/json`
     * but can be overridden here. When no JSON body is sent, `Content-Type` is removed after
     * these headers are merged.
     */
    headers?: HeadersInit | ((variables: TVariables) => HeadersInit);
}
export interface RailsActionCallOptions {
    headers?: HeadersInit;
    signal?: AbortSignal;
}
export interface RailsActionMutationFunctionContext {
    client: unknown;
    meta: Record<string, unknown> | undefined;
    mutationKey?: readonly unknown[];
}
export type RailsActionCallerOptions = RailsActionCallOptions | RailsActionMutationFunctionContext;
type RailsActionNoVariables = ReturnType<() => void>;
export type RailsActionCaller<TVariables, TResponse> = [TVariables] extends [RailsActionNoVariables] ? (variables?: RailsActionNoVariables, options?: RailsActionCallerOptions) => Promise<TResponse> : (variables: TVariables, options?: RailsActionCallerOptions) => Promise<TResponse>;
export declare class RailsActionRequestError<TResponseBody = unknown> extends Error {
    readonly response: Response;
    readonly responseBody: TResponseBody;
    readonly cause?: unknown;
    constructor(response: Response, responseBody: TResponseBody, options?: {
        cause?: unknown;
    });
}
/**
 * Creates a CSRF-aware JSON caller for a Rails controller action.
 *
 * Supply the response generic from the generated Rails response declarations:
 *
 * ```ts
 * type CreateProjectResponse = RailsResponseType<'projects.create'>;
 * const createProject = createRailsAction<CreateProjectVariables, CreateProjectResponse>({
 *   path: '/api/projects',
 * });
 * ```
 *
 * The returned function is directly usable as a TanStack Query `mutationFn`.
 * It always requests JSON, rejects browser-followed redirects, and resolves 204 or non-JSON success
 * responses as `null`. Include `null` in `TResponse` when a successful empty response is expected.
 * A 200 response with `text/html`, such as an unexpected Rails error page, also resolves as `null`.
 * `options.headers` can override the default `Accept: application/json`; include `null` in `TResponse`
 * when that custom Accept header may produce a successful non-JSON response.
 * Omitting `body` sends `variables` as the JSON body verbatim; supply `body` to map or filter fields before
 * serialization.
 * Body values that would serialize lossy or outside JSON, including nested `undefined`, `BigInt`, and
 * non-finite numbers, are rejected before `fetch` runs.
 * When `variables` only populate `path`, supply `body: () => null` or a mapper to avoid forwarding them.
 * Return `null` or `undefined` from `body` when the request should not send JSON. DELETE requests never
 * send a JSON body; identify the resource in the URL instead.
 */
export declare function createRailsAction<TVariables = undefined, TResponse = unknown>(options: RailsActionOptions<TVariables>): RailsActionCaller<TVariables, TResponse>;
export {};
//# sourceMappingURL=railsAction.d.ts.map