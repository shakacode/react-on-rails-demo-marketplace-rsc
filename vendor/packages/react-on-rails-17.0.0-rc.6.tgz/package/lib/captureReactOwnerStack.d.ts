/**
 * Whether React's dev-only `captureOwnerStack` API exists in the current build — i.e. React >= 19.1
 * running its **development** build. Used to gate dev-mode owner-stack logging so that on older
 * React (or any production build), where the API is absent, React's own default error reporting is
 * left untouched (issue #3887).
 */
export declare function isOwnerStackSupported(): boolean;
export default function captureReactOwnerStack(): string | undefined;
//# sourceMappingURL=captureReactOwnerStack.d.ts.map