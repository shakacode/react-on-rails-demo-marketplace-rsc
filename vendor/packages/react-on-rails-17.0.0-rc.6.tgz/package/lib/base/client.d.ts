/**
 * @deprecated Use `capabilities/core.ts` instead. This file is kept for backward compatibility
 * with older versions of react-on-rails-pro that import from `react-on-rails/@internal/base/client`.
 */
import type { RegisteredComponent, RegisteredComponentValue, Store, StoreGenerator, ReactOnRailsInternal } from '../types/index.ts';
type RegisteredComponentEntry = RegisteredComponent<RegisteredComponentValue>;
interface Registries {
    ComponentRegistry: {
        register: (components: Record<string, RegisteredComponentValue>) => void;
        get: (name: string) => RegisteredComponentEntry;
        components: () => Map<string, RegisteredComponentEntry>;
    };
    StoreRegistry: {
        register: (storeGenerators: Record<string, StoreGenerator>) => void;
        getStore: (name: string, throwIfMissing?: boolean) => Store | undefined;
        getStoreGenerator: (name: string) => StoreGenerator;
        setStore: (name: string, store: Store) => void;
        clearHydratedStores: () => void;
        clearStoreGenerators: () => void;
        storeGenerators: () => Map<string, StoreGenerator>;
        stores: () => Map<string, Store>;
    };
}
/**
 * Base client object type that includes all core ReactOnRails methods except Pro-specific ones.
 * Derived from ReactOnRailsInternal by omitting Pro-only methods.
 */
export type BaseClientObjectType = Omit<ReactOnRailsInternal, 'getOrWaitForComponent' | 'getOrWaitForStore' | 'getOrWaitForStoreGenerator' | 'reactOnRailsStoreLoaded' | 'streamServerRenderedReactComponent' | 'serverRenderRSCReactComponent' | 'addAsyncPropsCapabilityToComponentProps' | 'getOrCreateAsyncPropsManager'>;
export declare function createBaseClientObject(registries: Registries, currentObject?: BaseClientObjectType | null): BaseClientObjectType;
export {};
//# sourceMappingURL=client.d.ts.map