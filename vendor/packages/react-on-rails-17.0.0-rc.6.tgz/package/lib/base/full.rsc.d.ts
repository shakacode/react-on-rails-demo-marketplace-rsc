/**
 * @deprecated Use `capabilities/ssr.rsc.ts` instead. This file is kept for backward compatibility
 * with older versions of react-on-rails-pro that import from `react-on-rails/@internal/base/full`.
 */
import { createBaseClientObject, type BaseClientObjectType } from './client.ts';
import type { BaseFullObjectType } from './full.ts';
export type * from './full.ts';
export declare function createBaseFullObject(registries: Parameters<typeof createBaseClientObject>[0], currentObject?: BaseClientObjectType | null): BaseFullObjectType;
//# sourceMappingURL=full.rsc.d.ts.map