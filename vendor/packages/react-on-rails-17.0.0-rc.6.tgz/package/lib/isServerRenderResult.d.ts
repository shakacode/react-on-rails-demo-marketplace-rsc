import type { ServerRenderResult } from './types/index.ts';
export declare function isServerRenderHash(testValue: unknown): testValue is ServerRenderResult;
export declare function isPromise<T>(testValue: unknown): testValue is Promise<T>;
//# sourceMappingURL=isServerRenderResult.d.ts.map