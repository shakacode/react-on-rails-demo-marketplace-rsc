import type { Registries } from './capabilities/core.ts';
import type { ReactOnRailsInternal } from './types/index.ts';
export type { Registries };
/**
 * Assembles the ReactOnRails global object from an array of capabilities.
 *
 * Each capability is a partial implementation of ReactOnRailsInternal.
 * Capabilities are merged in array order (last wins for overlapping keys).
 *
 * @param capabilities - Array of capability objects to merge.
 * @param options.currentGlobal - Current globalThis.ReactOnRails value (for misconfiguration detection).
 * @param options.startup - Callback invoked once on first initialization, after the global is set.
 * @param options.registries - The registries used by the core capability (for mixing detection).
 */
export default function createReactOnRails(capabilities: Partial<ReactOnRailsInternal>[], options: {
    currentGlobal: ReactOnRailsInternal | null;
    startup: (() => void) | null;
    registries: Registries;
}): ReactOnRailsInternal;
//# sourceMappingURL=createReactOnRails.d.ts.map